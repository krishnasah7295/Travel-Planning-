package com.vaatu.tripmate.utils;

public class UserModel {

    String name;
    String emsil;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmsil() {
        return emsil;
    }

    public void setEmsil(String emsil) {
        this.emsil = emsil;
    }
}
